package com.redmart;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;
import java.util.ArrayList;
import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends Activity implements ItemsLoadable {

    @BindView(R.id.gridView)//Reduce boiler plate code
    GridView gridView;

    private ArrayList<Item> itemArrayList;
    private boolean flagLoading = false;//Currently, are there any items loading?
    private HttpItems client;
    private int page = 0;//page number of the url
    private ItemAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        this.itemArrayList = new ArrayList<Item>();

        //API call: Load the 0 page first with 20 items
        client = new HttpItems(MainActivity.this, this);
        String url = "https://api.redmart.com/v1.5.7/catalog/search?page=" + page + "&pageSize=20";
        client.getData(url);
    }

    /*--------------------------------------------------------------------------------------------*/
    // After loading the items from API (client.getData(url)) run below callback function
    /*--------------------------------------------------------------------------------------------*/
    @Override
    public void onItemsLoaded(ArrayList<Item> itemsArray) {
        Log.d("test", "callback");
        this.itemArrayList.addAll(itemsArray);//each round append 20 more items into the main array
        flagLoading = false;
        setGridView(this.itemArrayList);
        Log.d("test", "itemArrayList size ->" + itemArrayList.size());
    }

    /*--------------------------------------------------------------------------------------------*/
    //Set items in the grid
    /*--------------------------------------------------------------------------------------------*/
    private void setGridView(ArrayList<Item> itemsArray) {
        if (page == 0) { //run below code only once
            adapter = new ItemAdapter(MainActivity.this, itemsArray);
            this.gridView.setAdapter(adapter);
            this.gridView.setOnScrollListener(EndlessScrollListener);
            this.gridView.setOnItemClickListener(ItemClickListener);

        } else {
            //Update adapter for each load more calls
            Log.d("test", "item added");
            adapter.notifyDataSetChanged();
        }
    }

    /*--------------------------------------------------------------------------------------------*/
    // List click listener
    /*--------------------------------------------------------------------------------------------*/
    private AdapterView.OnItemClickListener ItemClickListener = new AdapterView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            Item clickedItem = itemArrayList.get(position);
            Log.d("test", clickedItem.getName() + " clicked");//go to details screen

            Intent i = new Intent(MainActivity.this, DetailsActivity.class);
            i.putExtra("clickedItem", clickedItem);
            startActivity(i);
        }
    };

    /*--------------------------------------------------------------------------------------------*/
    // Pagination - on scroll append items
    /*--------------------------------------------------------------------------------------------*/
    private AbsListView.OnScrollListener EndlessScrollListener = new AbsListView.OnScrollListener() {
        @Override
        public void onScrollStateChanged(AbsListView view, int scrollState) {
            //Log.d("test", "state ->" + scrollState);
        }

        @Override
        public void onScroll(AbsListView view, int firstVisibleItem, int visibleItemCount, int totalItemCount) {

            if (firstVisibleItem + visibleItemCount == totalItemCount && totalItemCount != 0) {
                if (flagLoading == false) {//disable below code while loading

                    flagLoading = true;
                    page++;
                    String url = "https://api.redmart.com/v1.5.7/catalog/search?page=" + page + "&pageSize=20";
                    client.getData(url);

                    Log.d("test", "Loading page .." + page);
                    Toast.makeText(MainActivity.this, "Loading page " + page + "\nArray Size:" + itemArrayList.size(), Toast.LENGTH_SHORT).show();
                }
            }
        }
    };




}//end
