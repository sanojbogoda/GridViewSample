package com.redmart;

import android.content.Context;
import android.support.v4.view.PagerAdapter;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class GalleryAdapter extends PagerAdapter {

    private Context context;
    private ArrayList<String> images;
    private int count;

    //init
    public GalleryAdapter(Context context, ArrayList<String> images) {
        this.context = context;
        this.images = images;
    }

    //test url :
    //"http://media.redmart.com/newmedia/200p/i/m/8885003327338-3_1433995309575.jpg"
    @Override
    public Object instantiateItem(ViewGroup container, int position) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View layout = inflater.inflate(R.layout.cell_gallery, null);

        //set gallery image
        String imageUrl = this.images.get(position);
        ImageView imageView = (ImageView) layout.findViewById(R.id.imageView);
        Picasso.with(context).load(imageUrl).into(imageView);

        //set photo index indicator
        TextView tvCount = (TextView) layout.findViewById(R.id.tvCount);
        tvCount.setText("< " + (position + 1) + " of " + this.count + " Photos >");

        container.addView(layout, 0);
        return layout;
    }

    @Override
    public int getCount() {
        this.count = images.size();
        return this.count;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
        container.removeView((View) object);
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == object;
    }


}//end
