package com.redmart;

import java.io.Serializable;
import java.util.ArrayList;

public class Item implements Serializable {

    public String id;
    public String name;
    public String imageUrl;
    public String price;
    public String desc;
    public String promotion;
    public String measure;
    public ArrayList<String> images;

    public Item() {
    }

    public ArrayList<String> getImages() {
        return images;
    }

    public void setImages(ArrayList<String> images) {
        this.images = images;
    }

    public String getMeasure() { return measure; }

    public void setMeasure(String measure) {
        this.measure = measure;
    }

    public String getPromotion() {
        return promotion;
    }

    public void setPromotion(String promotion) {
        this.promotion = promotion;
    }

    public String getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public String getPrice() {
        return price;
    }

    public String getDesc() {
        return desc;
    }

    public void setId(String id) { this.id = id; }

    public void setName(String name) {
        this.name = name;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }
}
