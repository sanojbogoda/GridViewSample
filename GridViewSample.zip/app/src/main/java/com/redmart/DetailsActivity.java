package com.redmart;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

import butterknife.BindView;
import butterknife.ButterKnife;

public class DetailsActivity extends Activity {

    @BindView(R.id.viewPager)
    ViewPager viewPager;
    @BindView(R.id.tvName)
    TextView tvName;
    @BindView(R.id.tvPrice)
    TextView tvPrice;
    @BindView(R.id.tvPromo)
    TextView tvPromo;
    @BindView(R.id.tvMeasure)
    TextView tvMeasure;
    @BindView(R.id.tvDesc)
    TextView tvDesc;
    @BindView(R.id.btnBack)
    ImageButton btnBack;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
        ButterKnife.bind(this);

        Intent i = getIntent();
        if(i.hasExtra("clickedItem")) {

            Item item = (Item) i.getSerializableExtra("clickedItem");
            //set view pager
            if (item.getImages().size() > 0) {
                GalleryAdapter adapter = new GalleryAdapter(this, item.getImages());
                this.viewPager.setAdapter(adapter);
            }
            //set details
            tvName.setText(item.getName());
            tvPrice.setText(item.getPrice());
            tvPromo.setText(item.getPromotion());
            tvMeasure.setText(item.getMeasure());
            tvDesc.setText(item.getDesc());
        }

        //back
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

    }






}//end
