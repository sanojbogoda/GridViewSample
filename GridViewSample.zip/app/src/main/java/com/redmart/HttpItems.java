package com.redmart;

import android.content.Context;
import android.util.Log;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;


interface ItemsLoadable {
    void onItemsLoaded(ArrayList<Item> itemsArray);
}

public class HttpItems {

    private Context context;
    private ArrayList<Item> itemsArray;
    private ItemsLoadable itemsLoadable;

    public HttpItems(Context context, ItemsLoadable itemsLoadable) {
        this.context = context;
        this.itemsLoadable = itemsLoadable;
        this.itemsArray = new ArrayList<Item>();
    }

    //api call
    public void getData(String url) {
        RequestQueue queue = Volley.newRequestQueue(this.context);
        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                System.out.println("response" + response.toString());
                itemsArray = parseJson(response);
                itemsLoadable.onItemsLoaded(itemsArray);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                System.out.println("error");
            }
        });
        queue.add(jsObjRequest);
    }

    //parse API
    private ArrayList<Item> parseJson(JSONObject object) {
        ArrayList<Item> itemsArray = new ArrayList<Item>();
        try {

            JSONObject product;
            JSONArray products = object.getJSONArray("products");
            Log.d("test", "size : " + products.length());
            for (int i = 0; i < products.length(); i++) {
                product = products.getJSONObject(i);

                System.out.println("item -> " + product.getString("title"));

                Item item = new Item();
                item.setId(product.getInt("id") + "");
                item.setName(product.getString("title"));
                item.setDesc(product.getString("desc"));
                //image
                if (product.has("img")) {
                    JSONObject img = product.getJSONObject("img");
                    String url = "http://media.redmart.com/newmedia/200p" + img.getString("name");
                    item.setImageUrl(url);
                }
                //images array
                if (product.has("images")) {
                    ArrayList<String> imagesArray = new ArrayList<String>();
                    JSONArray images = product.getJSONArray("images");
                    if(images.length()>0) {
                        for (int n = 0; n < images.length(); n++) {
                            String url = "http://media.redmart.com/newmedia/200p" + images.getJSONObject(n).getString("name");
                            imagesArray.add(url);
                        }
                    }
                    item.setImages(imagesArray);
                }
                //price
                if (product.has("pricing")) {
                    JSONObject pricing = product.getJSONObject("pricing");
                    item.setPrice("$" + pricing.getDouble("price"));
                }
                //promotion
                if (product.has("promotions")) {
                    JSONArray promoArray = product.getJSONArray("promotions");
                    if (promoArray.length() > 0) {
                        JSONObject promo = promoArray.getJSONObject(0);
                        item.setPromotion(promo.getString("savings_text"));
                    }
                }
                //measure
                if (product.has("measure")) {
                    JSONObject measure = product.getJSONObject("measure");
                    item.setMeasure(measure.getString("wt_or_vol"));

                }
                itemsArray.add(item);
            }

        } catch (JSONException e) {
            Log.e("error", e.getMessage());
        }

        return itemsArray;

    }


}//end
