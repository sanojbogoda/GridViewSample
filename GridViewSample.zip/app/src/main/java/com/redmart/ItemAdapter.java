package com.redmart;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

public class ItemAdapter extends ArrayAdapter<Item> {

    Activity context;
    ArrayList<Item> data;
    ViewHolder viewHolder;

    public ItemAdapter(Activity context, ArrayList<Item> data) {
        super(context, R.layout.cell_item, data);
        this.context = context;
        this.data = data;
    }

    public static class ViewHolder {
        public ImageView imageView;
        public TextView tvName;
        public TextView tvDesc;
        public TextView tvPrice;
        public TextView tvPromo;
        public TextView tvMeasure;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View rowView = convertView;
        final int index = position;

        // reuse views
        if (rowView == null) {
            LayoutInflater inflater = context.getLayoutInflater();
            rowView = inflater.inflate(R.layout.cell_item, null);

            // configure view holder
            viewHolder = new ViewHolder();
            viewHolder.imageView = (ImageView) rowView.findViewById(R.id.imageView);
            viewHolder.tvName = (TextView) rowView.findViewById(R.id.tvName);
            viewHolder.tvPrice = (TextView) rowView.findViewById(R.id.tvPrice);
            viewHolder.tvDesc = (TextView) rowView.findViewById(R.id.tvDesc);
            viewHolder.tvPromo = (TextView) rowView.findViewById(R.id.tvPromo);
            viewHolder.tvMeasure = (TextView) rowView.findViewById(R.id.tvMeasure);
            rowView.setTag(viewHolder);
        }

        Item item = data.get(index);
        viewHolder = (ViewHolder) rowView.getTag();
        viewHolder.tvName.setText(item.getName());
        viewHolder.tvPrice.setText(item.getPrice());
        viewHolder.tvDesc.setText(item.getDesc());
        viewHolder.tvPromo.setText(item.getPromotion());
        viewHolder.tvMeasure.setText(item.getMeasure());
        Picasso.with(this.context).load(item.getImageUrl()).into(viewHolder.imageView);


        return rowView;
    }


}//end
